"""Simplified engineering calculations for supported educational cases."""
import math


def validate_positive(**values):
    for name, value in values.items():
        if not math.isfinite(float(value)) or float(value) <= 0:
            raise ValueError(f"{name} must be a finite positive number.")


def analyze_beam(span_m, width_m, depth_m, load_kN, E_GPa):
    """Simply supported rectangular beam with a central point load."""
    validate_positive(span_m=span_m, width_m=width_m, depth_m=depth_m,
                      load_kN=load_kN, E_GPa=E_GPa)
    L, b, d = float(span_m), float(width_m), float(depth_m)
    P, E = float(load_kN) * 1000.0, float(E_GPa) * 1e9
    I = b * d**3 / 12.0
    moment = P * L / 4.0
    shear = P / 2.0
    stress = moment * (d / 2.0) / I
    deflection = P * L**3 / (48.0 * E * I)
    return {
        "element": "Beam",
        "method": "Simply supported rectangular beam with a central point load",
        "area_m2": b * d,
        "I_m4": I,
        "moment_kNm": moment / 1000.0,
        "shear_kN": shear / 1000.0,
        "stress_MPa": stress / 1e6,
        "deflection_mm": deflection * 1000.0,
        "strain": stress / E,
        "assumptions": [
            "Prismatic rectangular section with ideal simple supports.",
            "Central point load, linear elasticity, and small deflection.",
            "No reinforcement design, code-compliance, or complete strength check.",
        ],
    }


def analyze_column(height_m, width_m, depth_m, load_kN, E_GPa):
    """Uniform column under concentric axial compression."""
    validate_positive(height_m=height_m, width_m=width_m, depth_m=depth_m,
                      load_kN=load_kN, E_GPa=E_GPa)
    L, b, d = float(height_m), float(width_m), float(depth_m)
    P, E = float(load_kN) * 1000.0, float(E_GPa) * 1e9
    area = b * d
    I_min = min(b * d**3 / 12.0, d * b**3 / 12.0)
    return {
        "element": "Column",
        "method": "Concentric axial load with ideal pinned-pinned Euler estimate",
        "area_m2": area,
        "stress_MPa": (P / area) / 1e6,
        "shortening_mm": (P * L / (area * E)) * 1000.0,
        "ideal_euler_load_kN": (math.pi**2 * E * I_min / L**2) / 1000.0,
        "assumptions": [
            "Uniform prismatic column and concentric axial load.",
            "Elastic shortening ignores creep, cracking, and nonlinear effects.",
            "Euler estimate assumes an ideal elastic column with pinned-pinned ends.",
            "Not a complete column capacity or stability design check.",
        ],
    }


def analyze_slab_strip(span_m, thickness_m, load_kN_m2, E_GPa):
    """One-metre-wide simply supported one-way slab strip under uniform load."""
    validate_positive(span_m=span_m, thickness_m=thickness_m,
                      load_kN_m2=load_kN_m2, E_GPa=E_GPa)
    L, d = float(span_m), float(thickness_m)
    q, E = float(load_kN_m2) * 1000.0, float(E_GPa) * 1e9
    line_load = q  # one-metre-wide strip
    I = d**3 / 12.0
    moment = line_load * L**2 / 8.0
    stress = moment * (d / 2.0) / I
    deflection = 5.0 * line_load * L**4 / (384.0 * E * I)
    return {
        "element": "Slab",
        "method": "One-metre-wide simply supported one-way strip under uniform load",
        "moment_kNm_per_m": moment / 1000.0,
        "stress_MPa": stress / 1e6,
        "deflection_mm": deflection * 1000.0,
        "assumptions": [
            "One-way slab strip; not a general two-way slab analysis.",
            "Uniform load, simple supports, linear elasticity, and small deflection.",
            "No reinforcement, punching shear, or code design checks.",
        ],
    }


def analyze_foundation(footing_length_m, footing_width_m, column_load_kN,
                       allowable_soil_kPa):
    """Simplified average pressure for a concentric rectangular footing."""
    validate_positive(footing_length_m=footing_length_m,
                      footing_width_m=footing_width_m,
                      column_load_kN=column_load_kN,
                      allowable_soil_kPa=allowable_soil_kPa)
    area = float(footing_length_m) * float(footing_width_m)
    pressure = float(column_load_kN) / area  # kN/m² = kPa
    allowable = float(allowable_soil_kPa)
    return {
        "element": "Foundation",
        "method": "Average pressure under a concentric load on a rectangular footing",
        "area_m2": area,
        "average_pressure_kPa": pressure,
        "allowable_soil_pressure_kPa": allowable,
        "average_pressure_below_allowable": pressure <= allowable,
        "assumptions": [
            "Vertical concentric load and uniform average contact pressure.",
            "Footing self-weight and eccentricity are not included.",
            "No settlement, sliding, overturning, punching, or structural checks.",
            "This comparison alone cannot establish foundation safety.",
        ],
    }


def analyze_bridge_girder(span_m, width_m, depth_m, load_kN, E_GPa):
    """Idealised girder example, not a complete bridge analysis."""
    result = analyze_beam(span_m, width_m, depth_m, load_kN, E_GPa)
    result["element"] = "Bridge girder"
    result["method"] = "Idealised simply supported girder with central point load"
    result["assumptions"].append(
        "Not a full bridge assessment; no moving-load envelope, load distribution, or fatigue checks."
    )
    return result
