"""Synthetic beam dataset generation and ML training/evaluation."""
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

FEATURES = ["span_m", "width_m", "depth_m", "load_N", "E_Pa"]
TARGETS = ["moment_Nm", "shear_N", "stress_Pa", "deflection_m", "strain"]


def generate_beam_dataset(n_samples=6000, seed=42):
    if n_samples < 100:
        raise ValueError("Use at least 100 samples.")
    rng = np.random.default_rng(seed)
    L = rng.uniform(2.0, 10.0, n_samples)
    b = rng.uniform(0.15, 0.50, n_samples)
    d = rng.uniform(0.20, 0.80, n_samples)
    P = rng.uniform(1000.0, 100000.0, n_samples)
    E = rng.uniform(15e9, 40e9, n_samples)
    I = b * d**3 / 12.0
    M = P * L / 4.0
    V = P / 2.0
    stress = M * (d / 2.0) / I
    delta = P * L**3 / (48.0 * E * I)
    strain = stress / E
    return pd.DataFrame({
        "span_m": L, "width_m": b, "depth_m": d, "load_N": P, "E_Pa": E,
        "moment_Nm": M, "shear_N": V, "stress_Pa": stress,
        "deflection_m": delta, "strain": strain,
    })


def train_beam_model(n_samples=6000, seed=42):
    data = generate_beam_dataset(n_samples, seed)
    development, test = train_test_split(data, test_size=0.20, random_state=seed)
    train, validation = train_test_split(development, test_size=0.20, random_state=seed)
    model = make_pipeline(
        StandardScaler(),
        RandomForestRegressor(n_estimators=100, min_samples_leaf=2,
                              random_state=seed, n_jobs=-1),
    )
    model.fit(train[FEATURES], train[TARGETS])
    validation_pred = model.predict(validation[FEATURES])
    validation_mae = mean_absolute_error(
        validation[TARGETS], validation_pred, multioutput="raw_values"
    )
    test_pred = model.predict(test[FEATURES])
    metrics = {}
    units = {"moment_Nm": "N·m", "shear_N": "N", "stress_Pa": "Pa",
             "deflection_m": "m", "strain": "dimensionless"}
    for i, target in enumerate(TARGETS):
        actual = test[target].to_numpy()
        pred = test_pred[:, i]
        metrics[target] = {
            "MAE": float(mean_absolute_error(actual, pred)),
            "RMSE": float(np.sqrt(mean_squared_error(actual, pred))),
            "R2": float(r2_score(actual, pred)),
            "unit": units[target],
        }
    metadata = {
        "model_name": "RandomForestRegressor",
        "task": "Simply supported rectangular beam with central point load",
        "dataset_type": "Synthetic physics-based analytical data",
        "samples_total": int(len(data)),
        "samples_train": int(len(train)),
        "samples_validation": int(len(validation)),
        "samples_test": int(len(test)),
        "validation_mae_by_target": {
            t: float(validation_mae[i]) for i, t in enumerate(TARGETS)
        },
        "metrics": metrics,
        "limitations": [
            "Synthetic analytical data, not measured field data.",
            "Approximates the equations used to generate the targets.",
            "Valid only for the specified beam assumptions and input ranges.",
            "Not a structural safety or code-compliance model.",
        ],
    }
    return model, metadata


def predict_beam(model, span_m, width_m, depth_m, load_kN, E_GPa):
    values = np.array([float(span_m), float(width_m), float(depth_m),
                       float(load_kN) * 1000.0, float(E_GPa) * 1e9])
    if not np.all(np.isfinite(values)) or np.any(values <= 0):
        raise ValueError("All beam inputs must be finite positive numbers.")
    ranges = [(2.0, 10.0), (0.15, 0.50), (0.20, 0.80),
              (1000.0, 100000.0), (15e9, 40e9)]
    for name, value, (low, high) in zip(FEATURES, values, ranges):
        if not low <= value <= high:
            raise ValueError(
                f"{name} is outside the ML training range ({low:g} to {high:g})."
            )
    pred = model.predict(pd.DataFrame([values], columns=FEATURES))[0]
    return dict(zip(TARGETS, map(float, pred)))
