# AI-Assisted Structural Analysis and What-If Simulator

Educational Civil Engineering application with simplified engineering calculations, a beam ML experiment, What-If comparisons, and visualizations.

## Implemented calculation cases
- Beam: simply supported rectangular beam with central point load.
- Column: concentric axial compression and ideal pinned-pinned Euler estimate.
- Slab: simply supported one-way strip under uniform loading.
- Foundation: simplified average pressure for a concentric rectangular footing.
- Bridge: idealised girder example.
- Highway: visible in the interface, but pavement analysis is not implemented yet.

## Machine learning
The initial model supports only the specified beam case. It is trained using synthetic physics-based analytical data. Held-out metrics indicate approximation of those equations, not real-world structural accuracy. Other elements do not use the beam model.

## Run locally
Install Python 3.10 or newer, then run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

In the app, open Step 4 and click **Train and evaluate beam model**.

## Limitations
This is an educational prototype, not a structural safety certification tool. It does not include complete code-based design, reinforcement design, full bridge analysis, or highway pavement analysis. Obtain qualified engineering review for real-world decisions.
