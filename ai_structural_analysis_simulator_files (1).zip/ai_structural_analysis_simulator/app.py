import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

from calculations import (
    analyze_beam, analyze_column, analyze_slab_strip,
    analyze_foundation, analyze_bridge_girder,
)
from ml_model import train_beam_model, predict_beam

st.set_page_config(page_title="AI Structural Analysis Simulator",
                   page_icon="🏗️", layout="wide")

st.markdown("""
<style>
.stApp {background: linear-gradient(135deg,#071426 0%,#102746 100%); color:#f8fafc;}
[data-testid="stSidebar"] {background:#0b1b32;}
h1,h2,h3,p,label {color:#f8fafc;}
div[data-testid="stMetric"] {
 background:rgba(30,58,95,.55); border:1px solid rgba(0,229,255,.3);
 border-radius:12px; padding:12px;
}
</style>
""", unsafe_allow_html=True)

st.title("🏗️ AI-Assisted Structural Analysis")
st.caption("Engineering calculations • ML experiment • What-If comparison")

if "beam_model" not in st.session_state:
    st.session_state.beam_model = None
if "beam_metadata" not in st.session_state:
    st.session_state.beam_metadata = None

steps = [
    "1. Select Element", "2. Enter Details", "3. Structural Analysis",
    "4. AI/ML Prediction", "5. What-If Comparison",
    "6. Visualize Results", "7. AI Recommendation",
]
ELEMENTS = ["Beam", "Column", "Slab", "Foundation", "Bridge", "Highway"]
if "element" not in st.session_state:
    st.session_state.element = "Beam"

with st.sidebar:
    st.header("Project Workflow")
    stage = st.radio("Choose a step", steps)
    st.divider()
    st.caption("Educational simulator — not a safety certification tool.")

st.progress((steps.index(stage) + 1) / len(steps))
st.subheader(stage)

if stage == steps[0]:
    selected = st.selectbox("Structural element", ELEMENTS,
                            index=ELEMENTS.index(st.session_state.element))
    if st.button("Save selection", type="primary"):
        st.session_state.element = selected
        st.success(f"Selected: {selected}")
    st.info(
        "Implemented calculation cases: beam, idealised axial column, "
        "one-way slab strip, simplified footing pressure, and idealised bridge girder. "
        "Highway pavement analysis is not implemented in this starter version."
    )

elif stage == steps[1]:
    element = st.session_state.element
    st.write(f"### Input parameters — {element}")
    if element in ("Beam", "Bridge"):
        with st.form("beam_inputs"):
            L = st.number_input("Span (m)", 2.0, 10.0, 5.0, 0.1)
            b = st.number_input("Width (m)", 0.15, 0.50, 0.25, 0.01)
            d = st.number_input("Depth (m)", 0.20, 0.80, 0.35, 0.01)
            P = st.number_input("Central point load (kN)", 1.0, 100.0, 20.0, 1.0)
            E = st.number_input("Young's modulus (GPa)", 15.0, 40.0, 25.0, 1.0)
            submitted = st.form_submit_button("Save inputs", type="primary")
        if submitted:
            st.session_state.inputs = {"span_m": L, "width_m": b, "depth_m": d,
                                       "load_kN": P, "E_GPa": E}
            st.session_state.original_inputs = dict(st.session_state.inputs)
            st.success("Inputs saved.")
    elif element == "Column":
        with st.form("column_inputs"):
            H = st.number_input("Column height (m)", 1.0, 10.0, 3.0, 0.1)
            b = st.number_input("Width (m)", 0.15, 1.0, 0.30, 0.01)
            d = st.number_input("Depth (m)", 0.15, 1.0, 0.30, 0.01)
            P = st.number_input("Axial load (kN)", 1.0, 5000.0, 500.0, 10.0)
            E = st.number_input("Young's modulus (GPa)", 15.0, 40.0, 25.0, 1.0)
            submitted = st.form_submit_button("Save inputs", type="primary")
        if submitted:
            st.session_state.inputs = {"height_m": H, "width_m": b, "depth_m": d,
                                       "load_kN": P, "E_GPa": E}
            st.session_state.original_inputs = dict(st.session_state.inputs)
            st.success("Inputs saved.")
    elif element == "Slab":
        with st.form("slab_inputs"):
            L = st.number_input("Span (m)", 1.0, 10.0, 4.0, 0.1)
            d = st.number_input("Thickness (m)", 0.08, 0.50, 0.15, 0.01)
            q = st.number_input("Uniform area load (kN/m²)", 0.1, 100.0, 5.0, 0.5)
            E = st.number_input("Young's modulus (GPa)", 15.0, 40.0, 25.0, 1.0)
            submitted = st.form_submit_button("Save inputs", type="primary")
        if submitted:
            st.session_state.inputs = {"span_m": L, "thickness_m": d,
                                       "load_kN_m2": q, "E_GPa": E}
            st.session_state.original_inputs = dict(st.session_state.inputs)
            st.success("Inputs saved.")
    elif element == "Foundation":
        with st.form("foundation_inputs"):
            L = st.number_input("Footing length (m)", 0.5, 8.0, 2.0, 0.1)
            B = st.number_input("Footing width (m)", 0.5, 8.0, 2.0, 0.1)
            P = st.number_input("Column load (kN)", 1.0, 10000.0, 500.0, 10.0)
            q = st.number_input("Allowable soil pressure (kPa)", 10.0, 1000.0, 200.0, 10.0)
            submitted = st.form_submit_button("Save inputs", type="primary")
        if submitted:
            st.session_state.inputs = {"footing_length_m": L, "footing_width_m": B,
                                       "column_load_kN": P, "allowable_soil_kPa": q}
            st.session_state.original_inputs = dict(st.session_state.inputs)
            st.success("Inputs saved.")
    else:
        st.warning("Highway pavement analysis is not implemented yet.")

elif stage == steps[2]:
    inputs = st.session_state.get("inputs")
    element = st.session_state.element
    if not inputs:
        st.warning("Go to Step 2 and save the required inputs first.")
    else:
        funcs = {
            "Beam": analyze_beam, "Bridge": analyze_bridge_girder,
            "Column": analyze_column, "Slab": analyze_slab_strip,
            "Foundation": analyze_foundation,
        }
        if element not in funcs:
            st.warning("No calculation method is implemented for this element.")
        else:
            result = funcs[element](**inputs)
            st.session_state.analysis_result = result
            st.success("Engineering calculation completed.")
            metric_map = {
                "Beam": [("Moment (kN·m)", "moment_kNm"),
                         ("Stress (MPa)", "stress_MPa"),
                         ("Deflection (mm)", "deflection_mm")],
                "Bridge": [("Girder moment (kN·m)", "moment_kNm"),
                           ("Girder stress (MPa)", "stress_MPa"),
                           ("Girder deflection (mm)", "deflection_mm")],
                "Column": [("Axial stress (MPa)", "stress_MPa"),
                           ("Shortening (mm)", "shortening_mm"),
                           ("Ideal Euler load (kN)", "ideal_euler_load_kN")],
                "Slab": [("Moment (kN·m/m)", "moment_kNm_per_m"),
                         ("Stress (MPa)", "stress_MPa"),
                         ("Deflection (mm)", "deflection_mm")],
                "Foundation": [("Area (m²)", "area_m2"),
                               ("Average pressure (kPa)", "average_pressure_kPa"),
                               ("Allowable pressure (kPa)", "allowable_soil_pressure_kPa")],
            }
            cols = st.columns(3)
            for col, (label, key) in zip(cols, metric_map[element]):
                col.metric(label, f"{result[key]:,.4g}")
            st.write("**Method:**", result["method"])
            st.write("**Assumptions and limitations:**")
            for item in result["assumptions"]:
                st.write(f"- {item}")
            if element == "Foundation":
                if result["average_pressure_below_allowable"]:
                    st.info("Average pressure is below the entered allowable value; other checks remain necessary.")
                else:
                    st.warning("Average pressure exceeds the entered allowable value. Seek qualified engineering review.")

elif stage == steps[3]:
    element = st.session_state.element
    st.write("The first ML model supports the defined beam case only.")
    if element not in ("Beam", "Bridge"):
        st.warning("No ML model is available for this element. The beam model is not used as a substitute.")
    else:
        if st.session_state.beam_model is None:
            st.warning("Beam model not trained in this app session.")
            if st.button("Train and evaluate beam model", type="primary"):
                with st.spinner("Generating synthetic data, training and evaluating..."):
                    model, metadata = train_beam_model()
                    st.session_state.beam_model = model
                    st.session_state.beam_metadata = metadata
                st.success("Training and evaluation completed in this session.")
        if st.session_state.beam_model is not None:
            metadata = st.session_state.beam_metadata
            st.success("Model trained and evaluated in this session.")
            st.write("**Model:**", metadata["model_name"])
            st.write("**Dataset:**", metadata["dataset_type"])
            st.write(f"Training samples: {metadata['samples_train']}")
            st.write(f"Test samples: {metadata['samples_test']}")
            target = st.selectbox("Evaluation target", list(metadata["metrics"]))
            st.json(metadata["metrics"][target])
            inputs = st.session_state.get("inputs")
            if inputs and element in ("Beam", "Bridge"):
                try:
                    pred = predict_beam(st.session_state.beam_model, **inputs)
                    st.write("### ML estimates")
                    display = {
                        "moment_Nm": ("Moment", 1000, "kN·m"),
                        "shear_N": ("Shear", 1000, "kN"),
                        "stress_Pa": ("Stress", 1e6, "MPa"),
                        "deflection_m": ("Deflection", 1000, "mm"),
                        "strain": ("Strain", 1, ""),
                    }
                    cols = st.columns(3)
                    for i, (key, (label, divisor, unit)) in enumerate(display.items()):
                        cols[i % 3].metric(label, f"{pred[key] / divisor:,.5g} {unit}")
                except ValueError as exc:
                    st.warning(str(exc))
            st.caption("Synthetic-data results approximate analytical equations; they are not validated against real structures.")

elif stage == steps[4]:
    inputs = st.session_state.get("inputs")
    element = st.session_state.element
    if not inputs:
        st.warning("Save the original inputs in Step 2 first.")
    elif element in ("Beam", "Bridge"):
        modified = dict(inputs)
        modified["load_kN"] = st.number_input(
            "Modified central load (kN)", 1.0, 100.0,
            float(inputs["load_kN"]), 1.0)
        modified["depth_m"] = st.number_input(
            "Modified depth (m)", 0.20, 0.80,
            float(inputs["depth_m"]), 0.01)
        if st.button("Run What-If comparison", type="primary"):
            fn = analyze_beam if element == "Beam" else analyze_bridge_girder
            st.session_state.comparison = (fn(**inputs), fn(**modified))
        comparison = st.session_state.get("comparison")
        if comparison:
            old, new = comparison
            keys = [k for k, v in old.items() if isinstance(v, (int, float))
                    and k in new and isinstance(new[k], (int, float))]
            rows = [{"Quantity": k, "Original": old[k], "Modified": new[k],
                     "Change": new[k] - old[k],
                     "Change (%)": ((new[k] - old[k]) / abs(old[k]) * 100)
                     if old[k] != 0 else None} for k in keys]
            st.dataframe(pd.DataFrame(rows), use_container_width=True)
    elif element == "Column":
        modified = dict(inputs)
        modified["load_kN"] = st.number_input("Modified axial load (kN)", 1.0, 5000.0,
                                              float(inputs["load_kN"]), 10.0)
        if st.button("Run What-If comparison", type="primary"):
            st.session_state.comparison = (analyze_column(**inputs), analyze_column(**modified))
        comparison = st.session_state.get("comparison")
        if comparison:
            old, new = comparison
            keys = [k for k, v in old.items() if isinstance(v, (int, float))
                    and k in new and isinstance(new[k], (int, float))]
            st.dataframe(pd.DataFrame([
                {"Quantity": k, "Original": old[k], "Modified": new[k],
                 "Change": new[k] - old[k]} for k in keys
            ]), use_container_width=True)
    elif element == "Slab":
        modified = dict(inputs)
        modified["load_kN_m2"] = st.number_input("Modified area load (kN/m²)", 0.1, 100.0,
                                                 float(inputs["load_kN_m2"]), 0.5)
        if st.button("Run What-If comparison", type="primary"):
            st.session_state.comparison = (analyze_slab_strip(**inputs), analyze_slab_strip(**modified))
        comparison = st.session_state.get("comparison")
        if comparison:
            old, new = comparison
            keys = [k for k, v in old.items() if isinstance(v, (int, float))
                    and k in new and isinstance(new[k], (int, float))]
            st.dataframe(pd.DataFrame([
                {"Quantity": k, "Original": old[k], "Modified": new[k],
                 "Change": new[k] - old[k]} for k in keys
            ]), use_container_width=True)
    elif element == "Foundation":
        modified = dict(inputs)
        modified["column_load_kN"] = st.number_input("Modified column load (kN)", 1.0, 10000.0,
                                                     float(inputs["column_load_kN"]), 10.0)
        if st.button("Run What-If comparison", type="primary"):
            st.session_state.comparison = (analyze_foundation(**inputs), analyze_foundation(**modified))
        comparison = st.session_state.get("comparison")
        if comparison:
            old, new = comparison
            keys = [k for k, v in old.items() if isinstance(v, (int, float))
                    and k in new and isinstance(new[k], (int, float))]
            st.dataframe(pd.DataFrame([
                {"Quantity": k, "Original": old[k], "Modified": new[k],
                 "Change": new[k] - old[k]} for k in keys
            ]), use_container_width=True)
    else:
        st.warning("Highway What-If analysis is not implemented yet.")

elif stage == steps[5]:
    result = st.session_state.get("analysis_result")
    if not result:
        st.info("Run Step 3 first.")
    else:
        element = st.session_state.element
        if element in ("Beam", "Bridge"):
            inputs = st.session_state.inputs
            L, b, d = inputs["span_m"], inputs["width_m"], inputs["depth_m"]
            P, E = inputs["load_kN"] * 1000, inputs["E_GPa"] * 1e9
            I = b * d**3 / 12
            x = [i * L / 200 for i in range(201)]
            y = []
            for xi in x:
                z = xi if xi <= L / 2 else L - xi
                y.append(P * z * (3 * L**2 - 4 * z**2) / (48 * E * I) * 1000)
            fig, ax = plt.subplots()
            ax.plot(x, y, label="Idealised elastic deflection")
            ax.set_xlabel("Position along span (m)")
            ax.set_ylabel("Deflection magnitude (mm)")
            ax.set_title("Beam/girder deflection shape")
            ax.grid(True)
            ax.legend()
            st.pyplot(fig)
            plt.close(fig)
        comparison = st.session_state.get("comparison")
        if comparison:
            old, new = comparison
            keys = [k for k, v in old.items() if isinstance(v, (int, float))
                    and k in new and isinstance(new[k], (int, float))]
            if keys:
                st.bar_chart(pd.DataFrame(
                    {"Original": [old[k] for k in keys],
                     "Modified": [new[k] for k in keys]}, index=keys))
        st.caption("Visualizations use simplified calculation outputs; they do not certify structural safety.")

elif stage == steps[6]:
    element = st.session_state.element
    result = st.session_state.get("analysis_result")
    if not result:
        st.info("Run Step 3 before requesting recommendations.")
    elif element in ("Beam", "Bridge"):
        st.write("- Review calculated bending moment, stress and deflection for the idealised load case.")
        st.write("- For a rectangular section, second moment of area depends on the cube of its depth.")
        st.write("- Confirm real supports, loads, material properties, detailing and design codes with a qualified engineer.")
    elif element == "Column":
        st.write("- Review axial stress and elastic shortening.")
        st.write("- The ideal Euler estimate is not a design capacity; end restraints, imperfections and code checks matter.")
    elif element == "Slab":
        st.write("- These results represent a one-way slab strip under uniform loading.")
        st.write("- Confirm slab action, reinforcement, punching shear and relevant design checks.")
    elif element == "Foundation":
        st.write("- Compare average pressure with the entered allowable value.")
        st.write("- Soil settlement, eccentricity and other failure modes are not checked here.")
    else:
        st.warning("Highway pavement analysis is not implemented; no prediction or recommendation is available.")
    st.warning("Educational prototype only. It does not replace complete structural design or professional review.")

st.divider()
st.caption("Beam ML model uses synthetic analytical data and is session-based. Other element-specific ML models are not included.")
